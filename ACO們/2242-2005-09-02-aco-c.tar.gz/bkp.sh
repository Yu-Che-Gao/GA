	tar -czvf  `date +%k%M-%F`-ACO-C.tar.gz *.c *.h *.inp *sh *.make   makefile  readme  man.tar
