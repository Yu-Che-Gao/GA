#define ANTS  25 
#define ncmax 5 
#define runs 2
#define gamma 0.1 
#define rho    0.1 

