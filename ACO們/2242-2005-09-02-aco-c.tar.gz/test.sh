rm obj.o
make -f obj.make && ./objfn
rm obj.o

